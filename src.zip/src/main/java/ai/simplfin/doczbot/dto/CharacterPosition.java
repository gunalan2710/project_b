package ai.simplfin.doczbot.dto;

import java.awt.Rectangle;

public class CharacterPosition {
    public Rectangle bounds;
    
    public CharacterPosition(int x, int y, int width, int height) {
        this.bounds = new Rectangle(x, y, width, height);
    }
}