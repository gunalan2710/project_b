package ai.simplfin.doczbot.services.masking;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.photo.Photo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ai.simplfin.doczbot.dto.AadhaarLocationDto;
import jakarta.annotation.PostConstruct;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;

@Service
public class PythonTextReplacementService {

	private static final Logger log = LoggerFactory.getLogger(PythonTextReplacementService.class);

	@Value("${opencv.native.lib.path}")
	private String opercvPath;

	@PostConstruct
	public void initOpenCV() {
		File dll = new File(opercvPath);
		if (!dll.exists()) {
			throw new RuntimeException("OpenCV DLL not found at: " + opercvPath);
		}
		System.load(opercvPath);
		System.out.println("✅ OpenCV native library loaded successfully!");
	}

	// Inner classes
	public static class Replacement {
		public int x, y;
		public String newText;
		public int fontSize;

		public Replacement(int x, int y, String newText, int fontSize) {
			this.x = x;
			this.y = y;
			this.newText = newText;
			this.fontSize = fontSize;
		}
	}

	private static class CharacterPosition {
		Rectangle bounds;

		CharacterPosition(int x, int y, int width, int height) {
			this.bounds = new Rectangle(x, y, width, height);
		}
	}

	// ============================================================================
	// MAIN ENTRY POINT - Enhanced precision masking
	// ============================================================================

	public BufferedImage replaceTextInImage(BufferedImage image, List<AadhaarLocationDto> locations,
			AadhaarMaskingService.MaskingType maskingType) throws Exception {
		return replaceTextInImagePrecise(image, locations, maskingType);
	}

	/**
	 * ENHANCED: Precise character-by-character masking with proper sizing
	 */
	public BufferedImage replaceTextInImagePrecise(BufferedImage image, List<AadhaarLocationDto> locations,
			AadhaarMaskingService.MaskingType maskingType) throws Exception {

		log.info("Starting PRECISE character-by-character masking for {} location(s)", locations.size());

		Mat matImage = bufferedImageToMat(image);

		for (AadhaarLocationDto loc : locations) {
			String aadhaarNumber = loc.getUid();
			char maskChar = (maskingType == AadhaarMaskingService.MaskingType.X) ? 'X' : '*';

			List<Rectangle> digitBoxes = loc.getDigitBoxes();
			if (digitBoxes == null || digitBoxes.size() != 3) {
				log.warn("Invalid digit boxes count: {}, expected 3 groups",
						digitBoxes == null ? 0 : digitBoxes.size());
				continue;
			}

			log.info("Processing Aadhaar: {}", aadhaarNumber);

			// Process only the first 2 groups (first 8 digits)
			for (int groupIdx = 0; groupIdx < 2; groupIdx++) { // <-- CHANGED: Only process groups 0 and 1
				Rectangle groupBox = digitBoxes.get(groupIdx);

				log.debug("Group {} - Box position: x={}, y={}, w={}, h={}", groupIdx, groupBox.x, groupBox.y,
						groupBox.width, groupBox.height);

				// Get individual digit rectangles using contour detection
				List<Rectangle> individualDigits = getIndividualDigitRectangles(groupBox, matImage);

				if (individualDigits.size() != 4) {
					log.warn("Group {} - Expected 4 digits, got {}. Using fallback division.", groupIdx,
							individualDigits.size());
					individualDigits = getFallbackDigitRectangles(groupBox);
				}

				// Process each digit in this group
				for (int digitIdx = 0; digitIdx < 4; digitIdx++) {

					// Since we're only processing groups 0 and 1, all digits here should be masked
					char targetChar = maskChar; // Use X or *

					Rectangle digitRect = individualDigits.get(digitIdx);

					log.debug("  Digit {}: char='{}', rect=[{},{},{},{}]", digitIdx, targetChar, digitRect.x,
							digitRect.y, digitRect.width, digitRect.height);

					// Process this single character
					processCharacterEnhanced(matImage, digitRect, targetChar, groupBox.height);
				}
			}
			// Group 3 (last 4 digits) is intentionally skipped - left unchanged
		}

		BufferedImage result = matToBufferedImage(matImage);
		matImage.release();

		log.info("Masking completed successfully");
		return result;
	}

	// ============================================================================
	// DIGIT RECTANGLE DETECTION
	// ============================================================================

	/**
	 * Get individual digit rectangles using contour detection
	 */
	private List<Rectangle> getIndividualDigitRectangles(Rectangle groupBox, Mat matImage) {
		List<Rectangle> digitRects = new ArrayList<>();

		try {
			// Extract the group region with padding
			int padding = 2;
			int x1 = Math.max(0, groupBox.x - padding);
			int y1 = Math.max(0, groupBox.y - padding);
			int x2 = Math.min(matImage.cols(), groupBox.x + groupBox.width + padding);
			int y2 = Math.min(matImage.rows(), groupBox.y + groupBox.height + padding);

			Mat roi = matImage.submat(new Rect(x1, y1, x2 - x1, y2 - y1));

			// Convert to grayscale
			Mat gray = new Mat();
			Imgproc.cvtColor(roi, gray, Imgproc.COLOR_BGR2GRAY);

			// Apply adaptive threshold for better digit separation
			Mat binary = new Mat();
			Imgproc.adaptiveThreshold(gray, binary, 255, Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY_INV,
					11, 2);

			// Find contours
			List<MatOfPoint> contours = new ArrayList<>();
			Mat hierarchy = new Mat();
			Imgproc.findContours(binary, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

			// Get bounding boxes and filter
			List<Rect> boxes = new ArrayList<>();
			for (MatOfPoint contour : contours) {
				Rect rect = Imgproc.boundingRect(contour);

				// Filter: must be reasonable size for a digit
				int minWidth = groupBox.width / 8;
				int minHeight = groupBox.height / 2;

				if (rect.width >= minWidth && rect.height >= minHeight) {
					boxes.add(rect);
				}
			}

			// Sort by x position (left to right)
			boxes.sort(Comparator.comparingInt(r -> r.x));

			// Take first 4 boxes (should be our 4 digits)
			for (int i = 0; i < Math.min(4, boxes.size()); i++) {
				Rect box = boxes.get(i);
				digitRects.add(new Rectangle(x1 + box.x, y1 + box.y, box.width, box.height));
			}

			// Cleanup
			gray.release();
			binary.release();
			hierarchy.release();

		} catch (Exception e) {
			log.warn("Contour detection failed: {}", e.getMessage());
		}

		return digitRects;
	}

	/**
	 * Fallback: Equal division if contour detection fails
	 */
	private List<Rectangle> getFallbackDigitRectangles(Rectangle groupBox) {
		List<Rectangle> digitRects = new ArrayList<>();
		int digitWidth = groupBox.width / 4;

		for (int i = 0; i < 4; i++) {
			digitRects.add(new Rectangle(groupBox.x + (i * digitWidth), groupBox.y, digitWidth, groupBox.height));
		}

		return digitRects;
	}

	// ============================================================================
	// CHARACTER PROCESSING - ENHANCED VERSION
	// ============================================================================

	/**
	 * Process single character with enhanced background matching and sizing
	 */
	private void processCharacterEnhanced(Mat matImage, Rectangle charRect, char character, int originalGroupHeight) {

		// Step 1: Sample background color
		Scalar bgColor = sampleBackgroundAdvanced(matImage, charRect);

		// Step 2: Create smooth mask
		Mat mask = createFeatheredMask(matImage, charRect);

		// Step 3: Inpaint the area
		Mat inpainted = new Mat();
		Photo.inpaint(matImage, mask, inpainted, 3.0, Photo.INPAINT_TELEA);

		// Step 4: Blend inpainted area
		blendInpaintedArea(matImage, inpainted, mask);

		// Step 5: Convert to BufferedImage for text drawing
		BufferedImage bufferedImg = matToBufferedImage(matImage);
		int previousY=0;
		// Step 6: Draw character with perfect sizing
		drawCharacterPerfect(bufferedImg, charRect, character, bgColor, originalGroupHeight, previousY);

		// Step 7: Convert back to Mat
		Mat newMat = bufferedImageToMat(bufferedImg);
		newMat.copyTo(matImage);

		// Cleanup
		newMat.release();
		mask.release();
		inpainted.release();
	}
	
	private String getDigitFromImage(BufferedImage img, Rectangle rect, ITesseract tesseract) {
	    BufferedImage digitImg = img.getSubimage(rect.x, rect.y, rect.width, rect.height);
	    try {
	        String digit = tesseract.doOCR(digitImg).trim();
	        return digit.length() > 0 ? digit : "?";
	    } catch (Exception e) {
	        System.out.println("OCR error: " + e.getMessage());
	        return "?";
	    }
	}

	/**
	 * FIXED: Draw character with correct size and perfect positioning
	 */
	private void drawCharacterPerfect(BufferedImage img, Rectangle rect, char character, Scalar bgColor, int unusedOriginalGroupHeight,
			int previousY) {

	    Graphics2D g2d = img.createGraphics();	
	    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
	    g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

	    int fontSize = rect.height;
	    Font maskFont = new Font("Arial", Font.BOLD, fontSize);
	    g2d.setFont(maskFont);

	    FontMetrics fm = g2d.getFontMetrics();
	    int charWidth = fontSize; // Use height for width, for uniform sizing
	    int ascent = fm.getAscent();
	    int descent = fm.getDescent();
	 // Assuming you have ITesseract instance `tesseract`
		Tesseract tesseract = new Tesseract();
		tesseract.setDatapath("C:\\Program Files\\Tesseract-OCR\\tessdata");
		tesseract.setLanguage("eng");
	    String actualDigit = getDigitFromImage(img, rect, tesseract);
	    System.out.println("OCR detected digit at ["+rect.x+","+rect.y+","+rect.width+","+rect.height+"]: " + actualDigit);
	    int x = rect.x + (rect.width - charWidth) / 2; // Horizontal center
	    int y;
	    if (!actualDigit.equals("1")) {
	    	y = rect.y + ((rect.height + ascent - descent) / 2); // Vertical center
	    }else {
	    	y = previousY;
	    }
	    System.out.println("X="+x+", Y="+y);
	    g2d.setColor(new Color((int) bgColor.val[2], (int) bgColor.val[1], (int) bgColor.val[0])); // Background fill
	    g2d.fillRect(rect.x, rect.y, rect.width, rect.height);

	    g2d.setColor(Color.BLACK);
	    g2d.drawString(String.valueOf(character), x, y);

	    g2d.dispose();
	}


	// ============================================================================
	// BACKGROUND SAMPLING AND INPAINTING
	// ============================================================================

	/**
	 * Advanced background sampling with median calculation
	 */
	private Scalar sampleBackgroundAdvanced(Mat img, Rectangle charRect) {
		List<Scalar> samples = new ArrayList<>();

		// Sample points around all 4 sides
		int[][] sampleOffsets = {
				// Left side
				{ -4, 0 }, { -4, charRect.height / 4 }, { -4, charRect.height / 2 }, { -4, 3 * charRect.height / 4 },
				// Right side
				{ charRect.width + 4, 0 }, { charRect.width + 4, charRect.height / 4 },
				{ charRect.width + 4, charRect.height / 2 }, { charRect.width + 4, 3 * charRect.height / 4 },
				// Top
				{ charRect.width / 4, -4 }, { charRect.width / 2, -4 }, { 3 * charRect.width / 4, -4 },
				// Bottom
				{ charRect.width / 4, charRect.height + 4 }, { charRect.width / 2, charRect.height + 4 },
				{ 3 * charRect.width / 4, charRect.height + 4 } };

		for (int[] offset : sampleOffsets) {
			int sampleX = charRect.x + offset[0];
			int sampleY = charRect.y + offset[1];

			if (sampleX >= 0 && sampleX < img.cols() && sampleY >= 0 && sampleY < img.rows()) {
				double[] pixel = img.get(sampleY, sampleX);
				if (pixel != null && pixel.length >= 3) {
					samples.add(new Scalar(pixel[0], pixel[1], pixel[2]));
				}
			}
		}

		if (samples.isEmpty()) {
			return new Scalar(255, 255, 255);
		}

		// Calculate median (more robust than mean)
		return calculateMedianColor(samples);
	}

	/**
	 * Calculate median color from samples
	 */
	private Scalar calculateMedianColor(List<Scalar> samples) {
		if (samples.isEmpty()) {
			return new Scalar(255, 255, 255);
		}

		List<Double> blues = samples.stream().map(s -> s.val[0]).sorted().collect(Collectors.toList());
		List<Double> greens = samples.stream().map(s -> s.val[1]).sorted().collect(Collectors.toList());
		List<Double> reds = samples.stream().map(s -> s.val[2]).sorted().collect(Collectors.toList());

		int mid = samples.size() / 2;
		return new Scalar(blues.get(mid), greens.get(mid), reds.get(mid));
	}

	/**
	 * Create feathered mask for smooth blending
	 */
	private Mat createFeatheredMask(Mat img, Rectangle rect) {
		Mat mask = Mat.zeros(img.size(), CvType.CV_8UC1);

		// Ensure valid coordinates
		int x1 = Math.max(0, rect.x);
		int y1 = Math.max(0, rect.y);
		int x2 = Math.min(img.cols(), rect.x + rect.width);
		int y2 = Math.min(img.rows(), rect.y + rect.height);

		if (x2 > x1 && y2 > y1) {
			Mat roi = mask.submat(new Rect(x1, y1, x2 - x1, y2 - y1));
			roi.setTo(new Scalar(255));
		}

		// Apply Gaussian blur for feathering
		Mat blurred = new Mat();
		Imgproc.GaussianBlur(mask, blurred, new Size(5, 5), 1.5);

		mask.release();
		return blurred;
	}

	/**
	 * Blend inpainted area smoothly into original
	 */
	private void blendInpaintedArea(Mat original, Mat inpainted, Mat mask) {
		Mat normalized = new Mat();
		mask.convertTo(normalized, CvType.CV_32F, 1.0 / 255.0);

		for (int y = 0; y < original.rows(); y++) {
			for (int x = 0; x < original.cols(); x++) {
				double alpha = normalized.get(y, x)[0];
				if (alpha > 0.01) {
					double[] origPixel = original.get(y, x);
					double[] inpaintPixel = inpainted.get(y, x);

					double[] blended = new double[3];
					for (int c = 0; c < 3; c++) {
						blended[c] = origPixel[c] * (1 - alpha) + inpaintPixel[c] * alpha;
					}
					original.put(y, x, blended);
				}
			}
		}
		normalized.release();
	}

	// ============================================================================
	// UTILITY METHODS
	// ============================================================================

	private static BufferedImage matToBufferedImage(Mat mat) {
		int type = mat.channels() == 1 ? BufferedImage.TYPE_BYTE_GRAY : BufferedImage.TYPE_3BYTE_BGR;
		BufferedImage bufferedImage = new BufferedImage(mat.cols(), mat.rows(), type);
		byte[] data = ((DataBufferByte) bufferedImage.getRaster().getDataBuffer()).getData();
		mat.get(0, 0, data);
		return bufferedImage;
	}

	private static Mat bufferedImageToMat(BufferedImage bufferedImage) {
		// Ensure we have 3-channel BGR image
		BufferedImage convertedImage = bufferedImage;
		if (bufferedImage.getType() != BufferedImage.TYPE_3BYTE_BGR) {
			convertedImage = new BufferedImage(bufferedImage.getWidth(), bufferedImage.getHeight(),
					BufferedImage.TYPE_3BYTE_BGR);
			Graphics2D g = convertedImage.createGraphics();
			g.drawImage(bufferedImage, 0, 0, null);
			g.dispose();
		}

		Mat mat = new Mat(convertedImage.getHeight(), convertedImage.getWidth(), CvType.CV_8UC3);
		byte[] data = ((DataBufferByte) convertedImage.getRaster().getDataBuffer()).getData();
		mat.put(0, 0, data);
		return mat;
	}
}