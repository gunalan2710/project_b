package ai.simplfin.doczbot.services.ocr;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import ai.simplfin.doczbot.services.ExtractionResult;
import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

/**
 * Tesseract OCR service for extracting text from images
 */
@Slf4j
@Service
public class TesseractOCRService {

	private static final Logger log = LoggerFactory.getLogger(TesseractOCRService.class);
	
    @Value("${tesseract.data.path:/usr/share/tesseract-ocr/4.00/tessdata}")
    private String tesseractDataPath;

    @Value("${tesseract.language:eng+hin}")
    private String tesseractLanguage;

    /**
     * Extracts text from image files using Tesseract OCR
     */
    public ExtractionResult extractText(MultipartFile file) {
        long startTime = System.currentTimeMillis();
        
        try {
            log.info("Starting Tesseract OCR extraction for file: {}", file.getOriginalFilename());
            
            // Read image from file
            BufferedImage image = ImageIO.read(file.getInputStream());
            if (image == null) {
                return createErrorResult("Could not read image from file", startTime);
            }
            
            // Configure Tesseract
            Tesseract tesseract = new Tesseract();
            
            try {
                tesseract.setDatapath(tesseractDataPath);
                tesseract.setLanguage(tesseractLanguage); // English + Hindi support
                tesseract.setPageSegMode(1); // Automatic page segmentation with OSD
                tesseract.setOcrEngineMode(1); // Neural nets LSTM engine only
                
                // Additional configuration for better accuracy
                tesseract.setTessVariable("user_defined_dpi", "300");
                tesseract.setTessVariable("tessedit_char_whitelist", 
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 .,:/()-");
                
            } catch (Exception configException) {
                log.warn("Could not set all Tesseract configurations, using defaults: {}", 
                        configException.getMessage());
                // Continue with default configuration
            }
            
            // Extract text
            String extractedText = tesseract.doOCR(image);
            long processingTime = System.currentTimeMillis() - startTime;
            
            if (extractedText == null || extractedText.trim().isEmpty()) {
                return createErrorResult("No text extracted from image", startTime);
            }
            
            // Clean up extracted text
            extractedText = cleanExtractedText(extractedText);
            
            log.info("Tesseract OCR extraction completed for file: {} in {}ms, extracted {} characters", 
                    file.getOriginalFilename(), processingTime, extractedText.length());
            
            return ExtractionResult.builder()
                    .success(true)
                    .extractedText(extractedText)
                    .methodUsed("TESSERACT_OCR")
                    .processingTimeMs(processingTime)
                    .confidence(0.75) // OCR generally has lower confidence than text-based extraction
                    .build();
            
        } catch (TesseractException e) {
            log.error("Tesseract OCR failed for file: {}", file.getOriginalFilename(), e);
            return createErrorResult("Tesseract OCR failed: " + e.getMessage(), startTime);
            
        } catch (IOException e) {
            log.error("Error reading image file: {}", file.getOriginalFilename(), e);
            return createErrorResult("Error reading image file: " + e.getMessage(), startTime);
            
        } catch (Exception e) {
            log.error("Unexpected error during OCR extraction for file: {}", file.getOriginalFilename(), e);
            return createErrorResult("Unexpected OCR error: " + e.getMessage(), startTime);
        }
    }
    
    /**
     * Cleans up extracted text by removing extra whitespace and formatting
     */
    private String cleanExtractedText(String text) {
        if (text == null) return "";
        
        return text
                .replaceAll("\\s+", " ") // Replace multiple whitespace with single space
                .replaceAll("\\n+", "\n") // Replace multiple newlines with single newline
                .trim();
    }
    
    /**
     * Creates error result with processing time
     */
    private ExtractionResult createErrorResult(String errorMessage, long startTime) {
        return ExtractionResult.builder()
                .success(false)
                .methodUsed("TESSERACT_OCR")
                .errorMessage(errorMessage)
                .processingTimeMs(System.currentTimeMillis() - startTime)
                .confidence(0.0)
                .build();
    }
}
