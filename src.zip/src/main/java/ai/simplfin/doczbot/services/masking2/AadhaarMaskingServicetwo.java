package ai.simplfin.doczbot.services.masking2;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ai.simplfin.doczbot.dto.AadhaarLocationDto;
import ai.simplfin.doczbot.services.masking2.EnhancedAadhaarMaskingServicetwo.MaskingStyle;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class AadhaarMaskingServicetwo {

	private static final Logger log = LoggerFactory.getLogger(AadhaarMaskingServicetwo.class);
	
    @Autowired
    private EnhancedAadhaarMaskingServicetwo enhancedMaskingService;

    // Optional: Make masking style configurable via application.properties
    @Value("${aadhaar.masking.style:SMART_BACKGROUND}")
    private String maskingStyleConfig;

    /**
     * Main method to mask Aadhaar numbers in an image
     */
    public BufferedImage maskAadhaarInImage(BufferedImage image, 
                                           List<AadhaarLocationDto> locations) {
        if (locations == null || locations.isEmpty()) {
            log.info("No Aadhaar numbers detected, returning original image");
            return image;
        }

        log.info("Found {} Aadhaar number(s) to mask", locations.size());

        // Get masking style from config or default to SMART_BACKGROUND
        MaskingStyle style = getMaskingStyle();
        log.info("Using masking style: {}", style);

        // Use enhanced masking service
        BufferedImage maskedImage = enhancedMaskingService.maskAadhaarNumbers(
            image, 
            locations, 
            style
        );

        log.info("Masking completed successfully");
        return maskedImage;
    }

    /**
     * Mask Aadhaar and save to file
     */
    public File maskAndSave(BufferedImage image, 
                           List<AadhaarLocationDto> locations,
                           String outputPath) throws IOException {
        
        BufferedImage maskedImage = maskAadhaarInImage(image, locations);
        
        File outputFile = new File(outputPath);
        outputFile.getParentFile().mkdirs(); // Create directories if they don't exist
        
        // Save as JPEG with high quality
        ImageIO.write(maskedImage, "JPEG", outputFile);
        
        log.info("Masked image saved to: {}", outputFile.getAbsolutePath());
        return outputFile;
    }

    /**
     * Get masking style from configuration
     */
    private MaskingStyle getMaskingStyle() {
        try {
            return MaskingStyle.valueOf(maskingStyleConfig.toUpperCase());
        } catch (IllegalArgumentException e) {
            log.warn("Invalid masking style '{}', using SMART_BACKGROUND", maskingStyleConfig);
            return MaskingStyle.SMART_BACKGROUND;
        }
    }

    /**
     * Allow dynamic style selection
     */
    public BufferedImage maskWithStyle(BufferedImage image, 
                                      List<AadhaarLocationDto> locations,
                                      MaskingStyle style) {
        return enhancedMaskingService.maskAadhaarNumbers(image, locations, style);
    }
}