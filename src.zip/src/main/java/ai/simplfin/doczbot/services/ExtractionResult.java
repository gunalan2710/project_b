package ai.simplfin.doczbot.services;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Internal class for extraction results
 */
public class ExtractionResult {
	private boolean success;
	private String extractedText;
	private String methodUsed;
	private String errorMessage;
	private long processingTimeMs;
	private double confidence;
	
    // Private constructor for Builder
    private ExtractionResult(Builder builder) {
        this.success = builder.success;
        this.extractedText = builder.extractedText;
        this.methodUsed = builder.methodUsed;
        this.errorMessage = builder.errorMessage;
        this.processingTimeMs = builder.processingTimeMs;
        this.confidence = builder.confidence;
    }

    // Static builder() method
    public static Builder builder() {
        return new Builder();
    }

    // Builder class
    public static class Builder {
        private boolean success;
        private String extractedText;
        private String methodUsed;
        private String errorMessage;
        private long processingTimeMs;
        private double confidence;

        public Builder success(boolean success) { this.success = success; return this; }
        public Builder extractedText(String extractedText) { this.extractedText = extractedText; return this; }
        public Builder methodUsed(String methodUsed) { this.methodUsed = methodUsed; return this; }
        public Builder errorMessage(String errorMessage) { this.errorMessage = errorMessage; return this; }
        public Builder processingTimeMs(long processingTimeMs) { this.processingTimeMs = processingTimeMs; return this; }
        public Builder confidence(double confidence) { this.confidence = confidence; return this; }

        public ExtractionResult build() {
            return new ExtractionResult(this);
        }
    }
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getExtractedText() {
		return extractedText;
	}
	public void setExtractedText(String extractedText) {
		this.extractedText = extractedText;
	}
	public String getMethodUsed() {
		return methodUsed;
	}
	public void setMethodUsed(String methodUsed) {
		this.methodUsed = methodUsed;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public long getProcessingTimeMs() {
		return processingTimeMs;
	}
	public void setProcessingTimeMs(long processingTimeMs) {
		this.processingTimeMs = processingTimeMs;
	}
	public double getConfidence() {
		return confidence;
	}
	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}
	
}
