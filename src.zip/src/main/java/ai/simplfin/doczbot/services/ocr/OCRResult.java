package ai.simplfin.doczbot.services.ocr;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Result class for OCR operations
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OCRResult {
    private boolean successful;
    private String extractedText;
    private String errorMessage;
    private String ocrMethod;
    private long processingTimeMs;
    private double confidence;
	public boolean isSuccessful() {
		return successful;
	}
	public void setSuccessful(boolean successful) {
		this.successful = successful;
	}
	public String getExtractedText() {
		return extractedText;
	}
	public void setExtractedText(String extractedText) {
		this.extractedText = extractedText;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getOcrMethod() {
		return ocrMethod;
	}
	public void setOcrMethod(String ocrMethod) {
		this.ocrMethod = ocrMethod;
	}
	public long getProcessingTimeMs() {
		return processingTimeMs;
	}
	public void setProcessingTimeMs(long processingTimeMs) {
		this.processingTimeMs = processingTimeMs;
	}
	public double getConfidence() {
		return confidence;
	}
	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}
}