package ai.simplfin.doczbot.services.masking;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import ai.simplfin.doczbot.controllers.IdDocumentController;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.AdditionalDetail;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.IdDocumentContent;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.IdType;
import lombok.extern.slf4j.Slf4j;


/**
 * Main servi
import lombok.Value;t extraction
 * Implements multiple extraction methods with AI fallback
 */
@Slf4j
@Service
public class DocumentMaskingService {

	private static final Logger log = LoggerFactory.getLogger(IdDocumentController.class);
	
	@Autowired
	private AadhaarMaskingService aadharService;
	
	public IdDocumentExtractionResult uploadDocumentImage(MultipartFile file, String extractionMethod, String idType, String masking,
			String maskingType) {
		String extractionId = UUID.randomUUID().toString();
        long startTime = System.currentTimeMillis();
        try {
        	if("aadhar".equals(idType)) {	
        	IdDocumentExtractionResult result = aadharService.maskAadhaarInDocument(file, maskingType);
        	return result;
        	}} catch (Exception e) {
        		long processingTime = System.currentTimeMillis() - startTime;
				log.error("Error in uploading document image "+e.getMessage());
				IdDocumentExtractionResult errorResult = createErrorResult(extractionId, file.getOriginalFilename(), e.getMessage());
	            errorResult.setProcessingTimeMs(processingTime);
	            errorResult.setExtractionTime(LocalDateTime.now());
	            return errorResult;
			}
		return null;
	}
	
    private IdDocumentExtractionResult createErrorResult(String extractionId, String fileName, String errorMessage) {
        return IdDocumentExtractionResult.builder()
                .id(extractionId)
                .fileName(fileName)
                .fileType("error")
                .idType(IdType.OTHER.getValue())
                .success(false)
                .errorMessage(errorMessage)
                .content(IdDocumentContent.builder()
                        .additionalDetails(Arrays.asList(
                                AdditionalDetail.builder()
                                        .info("ERROR")
                                        .value(errorMessage)
                                        .confidence(1.0)
                                        .build()
                        		 ))
                        .build())
                .build();
    }
}
