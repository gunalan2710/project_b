package ai.simplfin.doczbot.services.image;


import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import ai.simplfin.doczbot.services.ExtractionResult;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

/**
 * Llama Vision AI service for advanced document analysis
 * Provides AI-powered text extraction and document understanding
 */
@Slf4j
@Service
public class LlamaVisionService {
	
	private static final Logger log = LoggerFactory.getLogger(LlamaVisionService.class);

    @Value("${llama.vision.enabled:false}")
    private boolean llamaVisionEnabled;

    @Value("${llama.vision.api.url:http://localhost:11434/api/generate}")
    private String llamaVisionApiUrl;

    @Value("${llama.vision.model:llava:latest}")
    private String llamaVisionModel;

    @Value("${llama.vision.timeout:60}")
    private int timeoutSeconds;

    private final WebClient webClient;

    public LlamaVisionService() {
        this.webClient = WebClient.builder()
                .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    /**
     * Extracts text using AI vision capabilities
     */
    public ExtractionResult extractTextWithAI(MultipartFile file) {
        long startTime = System.currentTimeMillis();
        
        if (!llamaVisionEnabled) {
            log.warn("Llama Vision is disabled, cannot perform AI extraction");
            return createErrorResult("Llama Vision is disabled", startTime);
        }
        
        try {
            log.info("Starting AI-powered text extraction for file: {}", file.getOriginalFilename());
            
            // Convert file to base64 for AI processing
            String base64Image = Base64.getEncoder().encodeToString(file.getBytes());
            
            // Prepare AI request
            Map<String, Object> requestBody = new HashMap<>();
            requestBody.put("model", llamaVisionModel);
            requestBody.put("prompt", createExtractionPrompt());
            requestBody.put("images", new String[]{base64Image});
            requestBody.put("stream", false);
            
            // Make AI API call
            Mono<Map> responseMono = webClient.post()
                    .uri(llamaVisionApiUrl)
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .timeout(Duration.ofSeconds(timeoutSeconds));
            
            Map<String, Object> response = responseMono.block();
            
            if (response == null || !response.containsKey("response")) {
                return createErrorResult("Invalid AI response", startTime);
            }
            
            String extractedText = (String) response.get("response");
            long processingTime = System.currentTimeMillis() - startTime;
            
            if (extractedText == null || extractedText.trim().isEmpty()) {
                return createErrorResult("AI did not extract any text", startTime);
            }
            
            log.info("AI text extraction completed for file: {} in {}ms", 
                    file.getOriginalFilename(), processingTime);
            
            return ExtractionResult.builder()
                    .success(true)
                    .extractedText(extractedText.trim())
                    .methodUsed("AI_EXTRACTION")
                    .processingTimeMs(processingTime)
                    .confidence(0.85) // AI typically has good confidence
                    .build();
            
        } catch (Exception e) {
            log.error("AI text extraction failed for file: {}", file.getOriginalFilename(), e);
            return createErrorResult("AI extraction failed: " + e.getMessage(), startTime);
        }
    }
    
    /**
     * Checks if the AI model is available
     */
    public Mono<Boolean> isModelAvailable() {
        if (!llamaVisionEnabled) {
            return Mono.just(false);
        }
        
        try {
            return webClient.get()
                    .uri(llamaVisionApiUrl.replace("/api/generate", "/api/tags"))
                    .retrieve()
                    .bodyToMono(String.class)
                    .map(response -> response.contains(llamaVisionModel))
                    .timeout(Duration.ofSeconds(5))
                    .onErrorReturn(false);
        } catch (Exception e) {
            log.warn("Could not check AI model availability: {}", e.getMessage());
            return Mono.just(false);
        }
    }
    
    /**
     * Creates a prompt for AI text extraction
     */
    private String createExtractionPrompt() {
        return """
            Please extract all text from this document image. 
            Focus on extracting:
            - Names, dates, and ID numbers
            - Address information
            - Any official text or labels
            
            Provide the extracted text exactly as it appears in the document, 
            maintaining the original formatting where possible. 
            Do not add explanations or interpretations, just return the raw extracted text.
            """;
    }
    
    /**
     * Creates error result with processing time
     */
    private ExtractionResult createErrorResult(String errorMessage, long startTime) {
        return ExtractionResult.builder()
                .success(false)
                .methodUsed("AI_EXTRACTION")
                .errorMessage(errorMessage)
                .processingTimeMs(System.currentTimeMillis() - startTime)
                .confidence(0.0)
                .build();
    }
}