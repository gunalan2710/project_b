package ai.simplfin.doczbot.services;


import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.slf4j.Slf4j;



/**
 * Service for handling file operations like temporary file creation and cleanup
 */
@Slf4j
@Service
public class FileHandlingService {
	
	 private static final Logger log = LoggerFactory.getLogger(FileHandlingService.class);

    @Value("${app.temp.directory:${java.io.tmpdir}}")
    private String tempDirectory;

    @Value("${app.cleanup.enabled:true}")
    private boolean cleanupEnabled;

    /**
     * Copies uploaded file to temporary location
     */
    public File copyToTempLocation(MultipartFile file) throws IOException {
        // Ensure temp directory exists
        Path tempDir = Paths.get(tempDirectory);
        if (!Files.exists(tempDir)) {
            Files.createDirectories(tempDir);
            log.info("Created temp directory: {}"+ tempDir.toAbsolutePath());
        }

        // Generate unique filename
        String originalFilename = file.getOriginalFilename();
        String extension = getFileExtension(originalFilename);
        String uniqueFilename = "doc_" + UUID.randomUUID().toString() + "." + extension;
        
        Path tempFilePath = tempDir.resolve(uniqueFilename);
        
        // Copy file to temp location
        Files.copy(file.getInputStream(), tempFilePath, StandardCopyOption.REPLACE_EXISTING);
        
        log.info("Copied file {} to temp location: {}"+ originalFilename+"   "+ tempFilePath.toAbsolutePath());
        
        return tempFilePath.toFile();
    }

    /**
     * Cleans up temporary file
     */
    public void cleanupTempFile(File file) {
        if (file != null && file.exists() && cleanupEnabled) {
            try {
                Files.delete(file.toPath());
                log.info("Cleaned up temp file: {}"+ file.getAbsolutePath());
            } catch (IOException e) {
            	log.info("Failed to cleanup temp file: {}"+ file.getAbsolutePath()+ e);
            }
        }
    }

    /**
     * Checks if file is a PDF
     */
    public boolean isPdfFile(File file) {
        String filename = file.getName().toLowerCase();
        return filename.endsWith(".pdf");
    }

    /**
     * Checks if file is an image
     */
    public boolean isImageFile(File file) {
        String filename = file.getName().toLowerCase();
        return filename.endsWith(".png") || 
               filename.endsWith(".jpg") || 
               filename.endsWith(".jpeg") || 
               filename.endsWith(".gif") || 
               filename.endsWith(".bmp") || 
               filename.endsWith(".tiff") || 
               filename.endsWith(".tif");
    }

    /**
     * Gets file extension from filename
     */
    private String getFileExtension(String filename) {
        if (filename == null || filename.isEmpty()) {
            return "tmp";
        }
        int lastDotIndex = filename.lastIndexOf('.');
        if (lastDotIndex == -1) {
            return "tmp";
        }
        return filename.substring(lastDotIndex + 1);
    }
}