package ai.simplfin.doczbot.services.reader;


import org.apache.tika.Tika;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.metadata.TikaCoreProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import ai.simplfin.doczbot.services.ExtractionResult;
import lombok.extern.slf4j.Slf4j;

/**
 * Spring AI Tika service for document text extraction
 * Uses Apache Tika for processing various document formats
 */
@Slf4j
@Service
public class SpringAITikaService {

	private static final Logger log = LoggerFactory.getLogger(SpringAITikaService.class);
	
    private final Tika tika = new Tika();

    /**
     * Extracts text from documents using Spring AI with Tika
     */
    public ExtractionResult extractText(MultipartFile file) {
        long startTime = System.currentTimeMillis();
        
        try {
            log.info("Starting Spring AI Tika extraction for file: {}", file.getOriginalFilename());
            
            // Set up metadata for better processing
            Metadata metadata = new Metadata();
            metadata.set(TikaCoreProperties.RESOURCE_NAME_KEY, file.getOriginalFilename());
            metadata.set(Metadata.CONTENT_TYPE, file.getContentType());
            
            // Extract text using Tika
            String extractedText = tika.parseToString(file.getInputStream(), metadata);
            long processingTime = System.currentTimeMillis() - startTime;
            
            if (extractedText == null || extractedText.trim().isEmpty()) {
                return createErrorResult("No text extracted from document", startTime);
            }
            
            // Clean up extracted text
            extractedText = cleanExtractedText(extractedText);
            
            log.info("Spring AI Tika extraction completed for file: {} in {}ms, extracted {} characters", 
                    file.getOriginalFilename(), processingTime, extractedText.length());
            
            return ExtractionResult.builder()
                    .success(true)
                    .extractedText(extractedText)
                    .methodUsed("SPRING_AI_TIKA")
                    .processingTimeMs(processingTime)
                    .confidence(0.90) // Tika generally has high confidence for text-based documents
                    .build();
            
        } catch (Exception e) {
            log.error("Spring AI Tika extraction failed for file: {}", file.getOriginalFilename(), e);
            return createErrorResult("Spring AI Tika extraction failed: " + e.getMessage(), startTime);
        }
    }
    
    /**
     * Cleans up extracted text
     */
    private String cleanExtractedText(String text) {
        if (text == null) return "";
        
        return text
                .replaceAll("\\s+", " ")
                .replaceAll("\\n+", "\n")
                .trim();
    }
    
    /**
     * Creates error result with processing time
     */
    private ExtractionResult createErrorResult(String errorMessage, long startTime) {
        return ExtractionResult.builder()
                .success(false)
                .methodUsed("SPRING_AI_TIKA")
                .errorMessage(errorMessage)
                .processingTimeMs(System.currentTimeMillis() - startTime)
                .confidence(0.0)
                .build();
    }
}