package ai.simplfin.doczbot.services.masking;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import ai.simplfin.doczbot.dto.AadhaarLocationDto;
import lombok.extern.slf4j.Slf4j;
import net.sourceforge.tess4j.ITessAPI;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.Word;

@Service
@Slf4j
public class AadhaarDetectionService {

    private final Tesseract tesseract;

    // Suspicious keywords that indicate the number is NOT an Aadhaar
    private static final Set<String> SUSPICIOUS_KEYWORDS = Set.of(
        "NAME", "FATHER", "MOTHER", "S/O", "D/O", "W/O", "H/O",
        "DOB", "DATE", "BIRTH", "YEAR", "AGE",
        "ADDRESS", "HOUSE", "STREET", "CITY", "PIN", "POST",
        "MOBILE", "PHONE", "CELL", "EMAIL", "GMAIL",
        "GENDER", "MALE", "FEMALE", "TRANSGENDER",
        "A/C", "ACCOUNT", "BANK", "IFSC", "CARD",
        "REF", "REFERENCE", "ID", "PASSPORT", "DL", "LICENSE",
        "FORM", "APPLICATION", "SIGNATURE"
    );

    public AadhaarDetectionService(Tesseract tesseract) {
        this.tesseract = tesseract;
    }

    /**
     * Extract all potential 12-digit Aadhaar numbers, validate, and return locations.
     */
    public List<AadhaarLocationDto> findAadhaarNumbers(BufferedImage image) throws Exception {
        List<AadhaarLocationDto> locations = new ArrayList<>();
        List<Word> words = tesseract.getWords(image, ITessAPI.TessPageIteratorLevel.RIL_WORD);

        if (words == null || words.isEmpty()) {
            return locations;
        }

        System.out.println("\n=== STARTING AADHAAR DETECTION ===");
        System.out.println("Total words extracted: " + words.size());

        // Sort words top-to-bottom, left-to-right
        words.sort(
            Comparator.comparingInt((Word w) -> w.getBoundingBox().y)
                .thenComparingInt(w -> w.getBoundingBox().x)
        );

        final int Y_TOLERANCE = 35;
        final int X_GAP_MAX = 250;

        // Helper class for numeric words
        class NumWord {
            String raw;
            String digits;
            Rectangle rect;
            int index;

            NumWord(Word w, int idx) {
                this.raw = w.getText();
                this.digits = raw.replaceAll("\\D+", "");
                this.rect = w.getBoundingBox();
                this.index = idx;
            }

            boolean isFourDigits() {
                return digits.length() == 4;
            }

            @Override
            public String toString() {
                return digits + "@(" + rect.x + "," + rect.y + ")";
            }
        }

        List<NumWord> numWords = new ArrayList<>();
        for (int i = 0; i < words.size(); i++) {
            NumWord nw = new NumWord(words.get(i), i);
            if (!nw.digits.isEmpty()) {
                numWords.add(nw);
            }
        }
        
        System.out.print("Numeric words: ");
        for (NumWord nw : numWords) {
            System.out.print(nw.digits + " ");
        }
        System.out.println();
        System.out.println("Total numeric words found: " + numWords.size());
        
        // Debug: Print with coordinates
        System.out.println("Numeric words with positions:");
        for (NumWord nw : numWords) {
            System.out.println("  " + nw.toString());
        }

        List<Rectangle> maskedRegions = new ArrayList<>();
        Map<String, Integer> foundAadhaars = new HashMap<>(); // Track Aadhaar number -> count

        // Find all 4-digit groups
        List<NumWord> fourDigitGroups = numWords.stream()
            .filter(NumWord::isFourDigits)
            .collect(Collectors.toList());
        
        System.out.println("Found " + fourDigitGroups.size() + " four-digit groups");

        // Try all combinations of 3 four-digit groups
        for (int i = 0; i < fourDigitGroups.size() - 2; i++) {
            for (int j = i + 1; j < fourDigitGroups.size() - 1; j++) {
                for (int k = j + 1; k < fourDigitGroups.size(); k++) {
                    NumWord g1 = fourDigitGroups.get(i);
                    NumWord g2 = fourDigitGroups.get(j);
                    NumWord g3 = fourDigitGroups.get(k);

                    // Check if they're on roughly the same line (Y-coordinate)
                    int minY = Math.min(Math.min(g1.rect.y, g2.rect.y), g3.rect.y);
                    int maxY = Math.max(Math.max(g1.rect.y, g2.rect.y), g3.rect.y);
                    if (maxY - minY > Y_TOLERANCE) {
                        continue;
                    }

                    // Sort by X position to determine order
                    List<NumWord> sortedByX = new ArrayList<>(Arrays.asList(g1, g2, g3));
                    sortedByX.sort(Comparator.comparingInt(nw -> nw.rect.x));
                    
                    NumWord left = sortedByX.get(0);
                    NumWord middle = sortedByX.get(1);
                    NumWord right = sortedByX.get(2);

                    // Check gaps between groups
                    int gap1 = middle.rect.x - (left.rect.x + left.rect.width);
                    int gap2 = right.rect.x - (middle.rect.x + middle.rect.width);
                    
                    System.out.println("  Testing combination: " + left.digits + " " + middle.digits + " " + right.digits + 
                                     " | gaps: " + gap1 + ", " + gap2);
                    
                    if (gap1 < -10 || gap2 < -10 || gap1 > X_GAP_MAX || gap2 > X_GAP_MAX) {
                        System.out.println("    ❌ Gap check failed");
                        continue;
                    }

                    // Try both reading orders (left-to-right and right-to-left)
                    String leftToRight = left.digits + middle.digits + right.digits;
                    String rightToLeft = right.digits + middle.digits + left.digits;
                    
                    String validAadhaar = null;
                    boolean isReversed = false;
                    
                    // Try left-to-right first
                    System.out.println("    Validating (L->R): " + leftToRight);
                    if (isValidAadhaarFormat(leftToRight)) {
                        validAadhaar = leftToRight;
                        isReversed = false;
                    } 
                    // Try right-to-left
                    else {
                        System.out.println("    Validating (R->L): " + rightToLeft);
                        if (isValidAadhaarFormat(rightToLeft)) {
                            validAadhaar = rightToLeft;
                            isReversed = true;
                        }
                    }
                    
                    if (validAadhaar == null) {
                        System.out.println("    ❌ Invalid Aadhaar format in both directions");
                        continue;
                    }

                    // Skip VID (check for 4th group forming a proper 4-group sequence)
                    boolean isVID = false;
                    for (NumWord fourth : fourDigitGroups) {
                        if (fourth == g1 || fourth == g2 || fourth == g3) continue;
                        
                        // Stricter Y-tolerance for VID: must be on SAME line (within 15px)
                        if (Math.abs(fourth.rect.y - left.rect.y) <= 15) {
                            int leftMostX = left.rect.x;
                            int rightMostX = right.rect.x + right.rect.width;
                            
                            // Check if 4th group forms a valid continuation with similar gaps
                            if (fourth.rect.x > rightMostX) {
                                int gap3 = fourth.rect.x - rightMostX;
                                int avgGap = (gap1 + gap2) / 2;
                                
                                System.out.println("      Checking 4th group: " + fourth.digits + 
                                                 " | gap3=" + gap3 + " | avgGap=" + avgGap + 
                                                 " | diff=" + Math.abs(gap3 - avgGap));
                                
                                // 4th group must have consistent gap (within 20px of average)
                                if (gap3 > 0 && gap3 < 80 && Math.abs(gap3 - avgGap) < 20) {
                                    System.out.println("      ✓ Found 4th group forming VID: " + fourth.digits);
                                    isVID = true;
                                    break;
                                }
                            } else if (fourth.rect.x + fourth.rect.width < leftMostX) {
                                int gap0 = leftMostX - (fourth.rect.x + fourth.rect.width);
                                int avgGap = (gap1 + gap2) / 2;
                                
                                System.out.println("      Checking 4th group (left): " + fourth.digits + 
                                                 " | gap0=" + gap0 + " | avgGap=" + avgGap + 
                                                 " | diff=" + Math.abs(gap0 - avgGap));
                                
                                // 4th group must have consistent gap
                                if (gap0 > 0 && gap0 < 80 && Math.abs(gap0 - avgGap) < 20) {
                                    System.out.println("      ✓ Found 4th group forming VID: " + fourth.digits);
                                    isVID = true;
                                    break;
                                }
                            }
                        }
                    }

                    if (isVID || isNearVIDKeyword(words, left.index, left.rect.y, Y_TOLERANCE)) {
                        System.out.println("    ⚠️ Skipping VID");
                        continue;
                    }

                    // Calculate bounding rectangle
                    int minX = left.rect.x;
                    int maxX = right.rect.x + right.rect.width;
                    int maxYBottom = Math.max(
                        Math.max(left.rect.y + left.rect.height, middle.rect.y + middle.rect.height),
                        right.rect.y + right.rect.height
                    );
                    Rectangle candidateRect = new Rectangle(minX, minY, maxX - minX, maxYBottom - minY);

                    // Check for suspicious context
                    if (isNearSuspiciousContext(words, candidateRect, Y_TOLERANCE, validAadhaar)) {
                        System.out.println("    ⚠️ Skipping due to suspicious context");
                        continue;
                    }

                    // Check if this location overlaps with already masked regions
                    boolean isDuplicate = false;
                    for (Rectangle masked : maskedRegions) {
                        // Check if centers are too close (within 100px vertically)
                        int centerYCurrent = candidateRect.y + candidateRect.height / 2;
                        int centerYMasked = masked.y + masked.height / 2;
                        
                        if (Math.abs(centerYCurrent - centerYMasked) < 100) {
                            // Check horizontal overlap
                            int overlapLeft = Math.max(candidateRect.x, masked.x);
                            int overlapRight = Math.min(candidateRect.x + candidateRect.width, 
                                                       masked.x + masked.width);
                            
                            if (overlapRight > overlapLeft) {
                                // There is horizontal overlap
                                int overlapWidth = overlapRight - overlapLeft;
                                int minWidth = Math.min(candidateRect.width, masked.width);
                                
                                // If overlap is more than 70% of the smaller width, it's a duplicate
                                if (overlapWidth > minWidth * 0.7) {
                                    System.out.println("    ⚠️ Overlaps with existing detection (likely duplicate)");
                                    isDuplicate = true;
                                    break;
                                }
                            }
                        }
                    }
                    
                    if (isDuplicate) {
                        continue;
                    }

                    // Valid Aadhaar found - create proper display format
                    List<Rectangle> digitBoxes;
                    if (isReversed) {
                        digitBoxes = Arrays.asList(right.rect, middle.rect, left.rect);
                    } else {
                        digitBoxes = Arrays.asList(left.rect, middle.rect, right.rect);
                    }

                    locations.add(new AadhaarLocationDto(
                        validAadhaar,
                        minX,
                        minY,
                        maxX - minX,
                        maxYBottom - minY,
                        digitBoxes
                    ));

                    maskedRegions.add(candidateRect);
                    foundAadhaars.put(validAadhaar, foundAadhaars.getOrDefault(validAadhaar, 0) + 1);

                    String displayNumber = validAadhaar.substring(0, 4) + " " + 
                                          validAadhaar.substring(4, 8) + " " + 
                                          validAadhaar.substring(8, 12);
                    int occurrenceCount = foundAadhaars.get(validAadhaar);
                    System.out.println("    ✅ Valid Aadhaar #" + locations.size() + 
                        " at (" + minX + "," + minY + "): " + displayNumber + 
                        " (occurrence #" + occurrenceCount + ")");
                }
            }
        }

        System.out.println("=== DETECTION COMPLETE: " + locations.size() + " Aadhaar number(s) found ===\n");
        return locations;
    }

    private boolean isNearVIDKeyword(List<Word> words, int startIndex, int anchorY, int yTolerance) {
        int searchStart = Math.max(0, startIndex - 5);
        int searchEnd = Math.min(words.size(), startIndex + 8);

        for (int i = searchStart; i < searchEnd; i++) {
            Word word = words.get(i);
            String text = word.getText().toUpperCase().trim();
            if ((text.contains("VID") || text.equals("VID:") || text.equals("VID")) &&
                Math.abs(word.getBoundingBox().y - anchorY) <= (yTolerance * 3)) {
                return true;
            }
        }
        return false;
    }

    private boolean isNearSuspiciousContext(List<Word> allWords, Rectangle candidateRect, 
                                           int yTolerance, String aadhaarDigits) {
        final int searchRadius = 200;
        final int verticalTolerance = yTolerance * 2;
        
        int suspiciousCount = 0;

        for (Word word : allWords) {
            Rectangle wordRect = word.getBoundingBox();
            String text = word.getText().toUpperCase().trim();

            // Skip if too far vertically
            if (Math.abs(wordRect.y - candidateRect.y) > verticalTolerance) {
                continue;
            }

            // Compute horizontal distance
            int horizontalDist = Math.max(0, 
                Math.max(
                    candidateRect.x - (wordRect.x + wordRect.width),
                    wordRect.x - (candidateRect.x + candidateRect.width)
                )
            );

            if (horizontalDist > searchRadius) {
                continue;
            }

            // Check for specific STRONG indicators
            if (text.equals("MOBILE") || text.equals("PHONE") || text.contains("MOBILE:") ||
                text.equals("ACCOUNT") || text.equals("A/C") || text.contains("ACCOUNT")) {
                System.out.println("    ⚠️ Strong suspicious keyword nearby: " + text);
                return true;
            }

            // Check for DOB pattern
            String digits = text.replaceAll("\\D+", "");
            if (digits.length() >= 6 && text.contains("/") && 
                (text.contains("DOB") || text.contains("DATE"))) {
                System.out.println("    ℹ️ Found DOB field nearby: " + text);
                suspiciousCount++;
            }

            // Check for 10-digit mobile
            if (digits.length() == 10 && !text.contains("/") && digits.matches("[6-9]\\d{9}")) {
                System.out.println("    ℹ️ Found 10-digit number: " + digits);
                suspiciousCount++;
            }
        }

        // Only reject if we have MULTIPLE suspicious indicators
        if (suspiciousCount >= 3) {
            System.out.println("    ⚠️ Multiple suspicious indicators: " + suspiciousCount);
            return true;
        }

        return false;
    }

    private boolean isValidAadhaarFormat(String aadhaar) {
        if (aadhaar == null || !aadhaar.matches("\\d{12}")) {
            return false;
        }
        
        char firstDigit = aadhaar.charAt(0);
        if (firstDigit == '0' || firstDigit == '1') {
            return false;
        }

        return isValidAadhaar(aadhaar);
    }

    // Verhoeff algorithm for Aadhaar validation
    public static boolean isValidAadhaar(String aadhaar) {
        if (aadhaar == null || !aadhaar.matches("\\d{12}")) {
            return false;
        }
        
        int[][] d = {
            {0,1,2,3,4,5,6,7,8,9},
            {1,2,3,4,0,6,7,8,9,5},
            {2,3,4,0,1,7,8,9,5,6},
            {3,4,0,1,2,8,9,5,6,7},
            {4,0,1,2,3,9,5,6,7,8},
            {5,9,8,7,6,0,4,3,2,1},
            {6,5,9,8,7,1,0,4,3,2},
            {7,6,5,9,8,2,1,0,4,3},
            {8,7,6,5,9,3,2,1,0,4},
            {9,8,7,6,5,4,3,2,1,0}
        };

        int[][] p = {
            {0,1,2,3,4,5,6,7,8,9},
            {1,5,7,6,2,8,3,0,9,4},
            {5,8,0,3,7,9,6,1,4,2},
            {8,9,1,6,0,4,3,5,2,7},
            {9,4,5,3,1,2,6,8,7,0},
            {4,2,8,6,5,7,3,9,0,1},
            {2,7,9,3,8,0,6,4,1,5},
            {7,0,4,6,9,1,3,2,5,8}
        };

        int c = 0;
        int[] myArray = new int[aadhaar.length()];
        for (int i = 0; i < aadhaar.length(); i++) {
            myArray[i] = Integer.parseInt(aadhaar.substring(aadhaar.length() - i - 1, aadhaar.length() - i));
        }
        for (int i = 0; i < myArray.length; i++) {
            c = d[c][p[i % 8][myArray[i]]];
        }
        return c == 0;
    }
}