package ai.simplfin.doczbot.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import ai.simplfin.doczbot.dto.IdDocumentExtractionResult;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.AdditionalDetail;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.AddressDetails;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.IdDocumentContent;
import ai.simplfin.doczbot.dto.IdDocumentExtractionResult.IdType;
import ai.simplfin.doczbot.services.image.LlamaVisionService;
import ai.simplfin.doczbot.services.ocr.TesseractOCRService;
import ai.simplfin.doczbot.services.reader.SpringAITikaService;
import lombok.extern.slf4j.Slf4j;

/**
 * Main servi
import lombok.Value;t extraction
 * Implements multiple extraction methods with AI fallback
 */
@Slf4j
@Service
public class IdDocumentExtractionService {

	private static final Logger log = LoggerFactory.getLogger(IdDocumentExtractionService.class);
	
	@Autowired
    private TesseractOCRService tesseractOCRService;
	@Autowired
    private SpringAITikaService springAITikaService;
	@Autowired
    private LlamaVisionService llamaVisionService;
	@Autowired
    private FileHandlingService fileHandlingService;
    
    @Value("${llama.vision.enabled:false}")
    private boolean llamaVisionEnabled;

    /**
     * Main method to extract text from uploaded document
     * Supports multiple extraction methods with automatic fallback
     */
    public IdDocumentExtractionResult extractIdDocument(MultipartFile file, String extractionMethod, String idType) {
        String extractionId = UUID.randomUUID().toString();
        long startTime = System.currentTimeMillis();
        
        log.info("Starting ID document extraction for file: {} with ID: {} using method: {} and type: {}"+
                file.getOriginalFilename()+ extractionId+ extractionMethod+ idType);
        
        try {
            // Validate file
            validateFile(file);
            
            // Determine extraction method if not specified
            if (extractionMethod == null || "DEFAULT_FALLBACK".equals(extractionMethod)) {
                extractionMethod = determineExtractionMethod(file);
                log.info("Auto-selected extraction method: {} for file: {}", extractionMethod, file.getOriginalFilename());
            }
            
            // Extract text using selected method
            ExtractionResult extractionResult = performExtraction(file, extractionMethod);
            
            if (!extractionResult.isSuccess()) {
                log.warn("Primary extraction failed, attempting fallback methods");
                extractionResult = performFallbackExtraction(file);
            }
            
            if (!extractionResult.isSuccess()) {
                return createErrorResult(extractionId, file.getOriginalFilename(), 
                        "All extraction methods failed: " + extractionResult.getErrorMessage());
            }
            
            // Auto-detect document type if not specified
            if (idType == null || "AUTO".equals(idType)) {
                idType = detectDocumentType(extractionResult.getExtractedText());
            }
            
            // Process extracted text and build structured result
            IdDocumentExtractionResult result = buildStructuredResult(
                    extractionResult, extractionId, file.getOriginalFilename(), idType);
            
            long processingTime = System.currentTimeMillis() - startTime;
            result.setProcessingTimeMs(processingTime);
            result.setExtractionTime(LocalDateTime.now());
            result.setSuccess(true);
            
            log.info("ID document extraction completed successfully for file: {} in {}ms using method: {}"+
                    file.getOriginalFilename()+ processingTime+ extractionResult.getMethodUsed());
            
            return result;
            
        } catch (Exception e) {
            long processingTime = System.currentTimeMillis() - startTime;
            log.error("Error extracting ID document from file: {}", file.getOriginalFilename(), e);
            
            IdDocumentExtractionResult errorResult = createErrorResult(extractionId, file.getOriginalFilename(), e.getMessage());
            errorResult.setProcessingTimeMs(processingTime);
            errorResult.setExtractionTime(LocalDateTime.now());
            return errorResult;
        }
    }
    
    /**
     * Validates the uploaded file
     */
    private void validateFile(MultipartFile file) {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty");
        }
        
        // Check file size (max 10MB)
        if (file.getSize() > 10 * 1024 * 1024) {
            throw new IllegalArgumentException("File size exceeds 10MB limit");
        }
        
        // Check file type
        String contentType = file.getContentType();
        if (contentType == null || !isValidFileType(contentType)) {
            throw new IllegalArgumentException("Unsupported file type: " + contentType);
        }
    }
    
    /**
     * Checks if file type is supported
     */
    private boolean isValidFileType(String contentType) {
        return contentType.contains("pdf") || 
               contentType.contains("image") ||
               contentType.contains("jpeg") ||
               contentType.contains("png") ||
               contentType.contains("tiff") ||
               contentType.contains("bmp");
    }
    
    /**
     * Determines the best extraction method based on file type
     */
    private String determineExtractionMethod(MultipartFile file) {
        String contentType = file.getContentType();
        
        if (contentType != null) {
            if (contentType.contains("pdf")) {
                return "SPRING_AI_TIKA";
            } else if (contentType.contains("image")) {
                return "TESSERACT_OCR";
            }
        }
        
        return "SPRING_AI_TIKA"; // Default method
    }
    
    /**
     * Performs text extraction using specified method
     */
    private ExtractionResult performExtraction(MultipartFile file, String method) {
        switch (method.toUpperCase()) {
            case "SPRING_AI_TIKA":
                return springAITikaService.extractText(file);
            case "TESSERACT_OCR":
                return tesseractOCRService.extractText(file);
            case "AI_EXTRACTION":
                if (llamaVisionEnabled) {
                    return llamaVisionService.extractTextWithAI(file);
                } else {
                    log.warn("AI extraction requested but Llama Vision not enabled, falling back to Tika");
                    return springAITikaService.extractText(file);
                }
            default:
                throw new IllegalArgumentException("Unsupported extraction method: " + method);
        }
    }
    
    /**
     * Performs fallback extraction when primary method fails
     */
    private ExtractionResult performFallbackExtraction(MultipartFile file) {
        // Try methods in order of preference
        String[] methods = {"SPRING_AI_TIKA", "TESSERACT_OCR"};
        
        for (String method : methods) {
            try {
                log.info("Trying fallback method: {} for file: {}", method, file.getOriginalFilename());
                ExtractionResult result = performExtraction(file, method);
                
                if (result.isSuccess() && result.getExtractedText() != null && 
                    !result.getExtractedText().trim().isEmpty()) {
                    log.info("Fallback method {} successful for file: {}", method, file.getOriginalFilename());
                    return result;
                }
            } catch (Exception e) {
                log.warn("Fallback method {} failed for file: {}", method, file.getOriginalFilename(), e);
            }
        }
        
        return ExtractionResult.builder()
                .success(false)
                .methodUsed("ALL_METHODS_FAILED")
                .errorMessage("All extraction methods failed")
                .build();
    }
    
    /**
     * Detects document type from extracted text
     */
    private String detectDocumentType(String text) {
        if (text == null || text.trim().isEmpty()) {
            return IdType.OTHER.getValue();
        }
        
        String upperText = text.toUpperCase();
        
        if (upperText.contains("AADHAAR") || upperText.contains("AADHAR") || 
            upperText.contains("UNIQUE IDENTIFICATION") || upperText.contains("UIDAI") ||
            text.matches(".*\\b\\d{4}\\s+\\d{4}\\s+\\d{4}\\b.*")) {
            return IdType.AADHAR.getValue();
        } else if (upperText.contains("PERMANENT ACCOUNT NUMBER") || upperText.contains("PAN") ||
                   upperText.contains("INCOME TAX DEPARTMENT") ||
                   text.matches(".*\\b[A-Z]{5}\\d{4}[A-Z]\\b.*")) {
            return IdType.PAN.getValue();
        } else if (upperText.contains("DRIVING LICENCE") || upperText.contains("DRIVING LICENSE") ||
                   upperText.contains("DL NO") || upperText.contains("LICENCE NO")) {
            return IdType.DRIVING_LICENSE.getValue();
        } else if (upperText.contains("PASSPORT") || upperText.contains("REPUBLIC OF INDIA") ||
                   upperText.contains("PASSPORT NO")) {
            return IdType.PASSPORT.getValue();
        }
        
        return IdType.OTHER.getValue();
    }
    
    /**
     * Builds structured result from extracted text
     */
    private IdDocumentExtractionResult buildStructuredResult(
            ExtractionResult extractionResult, String extractionId, String fileName, String idType) {
        
        String extractedText = extractionResult.getExtractedText();
        
        // Extract structured data based on document type
        IdDocumentContent content = extractContentByType(extractedText, idType);
        content.setRawExtractedText(extractedText);
        
        // Add extraction metadata
        if (content.getAdditionalDetails() == null) {
            content.setAdditionalDetails(new ArrayList<>());
        }
        
        content.getAdditionalDetails().add(AdditionalDetail.builder()
                .info("EXTRACTION_METHOD")
                .value(extractionResult.getMethodUsed())
                .confidence(extractionResult.getConfidence())
                .build());
        
        content.getAdditionalDetails().add(AdditionalDetail.builder()
                .info("PROCESSING_TIME_MS")
                .value(String.valueOf(extractionResult.getProcessingTimeMs()))
                .confidence(1.0)
                .build());
        
        return IdDocumentExtractionResult.builder()
                .id(extractionId)
                .fileName(fileName)
                .fileType(determineFileType(fileName))
                .idType(idType)
                .extractionMethod(extractionResult.getMethodUsed())
                .content(content)
                .success(true)
                .build();
    }
    
    /**
     * Extracts content based on document type
     */
    /**
     * Extracts content based on document type
     */
    private IdDocumentContent extractContentByType(String text, String idType) {
        IdDocumentContent.Builder contentBuilder = IdDocumentContent.builder();
        List<AdditionalDetail> additionalDetails = new ArrayList<>();

        // Always normalize text (helps regex matching)
        String normalizedText = text.toUpperCase();

        // Extract reference ID based on document type
        String referenceId = extractReferenceId(normalizedText, idType);
        if (referenceId != null) {
            contentBuilder.referenceId(referenceId);
        }

        // Common fields
        extractNames(text, contentBuilder);
        extractGender(text, contentBuilder);
        extractDates(text, contentBuilder, idType);
        extractMobileNumber(text, contentBuilder);
        extractIssuingAuthority(text, contentBuilder, idType);

        // Address
        AddressDetails addressDetails = extractAddressDetails(text);
        contentBuilder.addressDetails(addressDetails);

        // Document-type specific extraction
        switch (idType.toUpperCase()) {
            case "AADHAR":
                extractAadharDetails(text, contentBuilder, additionalDetails);
                break;
            case "PAN":
                extractPanDetails(text, contentBuilder, additionalDetails);
                break;
            case "DRIVING_LICENSE":
                extractDrivingLicenseDetails(text, contentBuilder, additionalDetails);
                break;
            case "RATION_CARD":
                extractRationCardDetails(text, contentBuilder, additionalDetails);
                break;
            case "PASSPORT":
                extractPassportDetails(text, contentBuilder, additionalDetails);
                break;
        }

        contentBuilder.additionalDetails(additionalDetails);
        return contentBuilder.build();
    }

    private void extractAadharDetails(String text, IdDocumentContent.Builder contentBuilder, List<AdditionalDetail> details) {
        // DOB
        String dob = matchRegex(text, "(?i)DOB[:\\s]*([0-9/\\-]{8,10})");
        if (dob != null) contentBuilder.dateOfBirth(dob);
        details.add(AdditionalDetail.builder().info("CARD_TYPE").value("AADHAR").confidence(1.0).build());
    }

    private void extractPanDetails(String text, IdDocumentContent.Builder contentBuilder, List<AdditionalDetail> details) {
        // Father's name (if present)
        String fatherName = matchRegex(text, "(?i)Father['’]s Name[:\\s]*([A-Za-z ]+)");
        if (fatherName != null) details.add(AdditionalDetail.builder().info("FATHER_NAME").value(fatherName).confidence(0.9).build());
        details.add(AdditionalDetail.builder().info("CARD_TYPE").value("PAN").confidence(1.0).build());
    }

    private void extractDrivingLicenseDetails(String text, IdDocumentContent.Builder contentBuilder, List<AdditionalDetail> details) {
        String issueDate = matchRegex(text, "(?i)Date of Issue[:\\s]*([0-9/\\-]{8,10})");
        if (issueDate != null) contentBuilder.issuedDate(issueDate);

        String validTill = matchRegex(text, "(?i)(Valid Till|Expiry Date)[:\\s]*([0-9/\\-]{8,10})");
        if (validTill != null) contentBuilder.expiryDate(validTill);

        String bloodGroup = matchRegex(text, "(?i)Blood Group[:\\s]*([A-Z0-9+\\-]+)");
        if (bloodGroup != null) details.add(AdditionalDetail.builder().info("BLOOD_GROUP").value(bloodGroup).confidence(0.9).build());

        String relative = matchRegex(text, "(?i)(Son|Daughter|Wife) of[:\\s]*([A-Za-z ]+)");
        if (relative != null) details.add(AdditionalDetail.builder().info("RELATIVE").value(relative).confidence(0.9).build());

        details.add(AdditionalDetail.builder().info("CARD_TYPE").value("DRIVING_LICENSE").confidence(1.0).build());
    }

    private void extractRationCardDetails(String text, IdDocumentContent.Builder contentBuilder, List<AdditionalDetail> details) {
        String familyHead = matchRegex(text, "(?i)Head of Family[:\\s]*([A-Za-z ]+)");
        if (familyHead != null) details.add(AdditionalDetail.builder().info("HEAD_OF_FAMILY").value(familyHead).confidence(0.9).build());
        details.add(AdditionalDetail.builder().info("CARD_TYPE").value("RATION_CARD").confidence(1.0).build());
    }

    private void extractPassportDetails(String text, IdDocumentContent.Builder contentBuilder, List<AdditionalDetail> details) {
        String expiry = matchRegex(text, "(?i)Date of Expiry[:\\s]*([0-9/\\-]{8,10})");
        if (expiry != null) contentBuilder.expiryDate(expiry);
        String issue = matchRegex(text, "(?i)Date of Issue[:\\s]*([0-9/\\-]{8,10})");
        if (issue != null) contentBuilder.issuedDate(issue);
        details.add(AdditionalDetail.builder().info("CARD_TYPE").value("PASSPORT").confidence(1.0).build());
    }

    
    /**
     * Extracts reference ID (main ID number) based on document type
     */
    private String extractReferenceId(String text, String idType) {
        switch (idType.toUpperCase()) {
            case "AADHAR":
                return matchRegex(text, "\\b\\d{4}\\s+\\d{4}\\s+\\d{4}\\b"); // 12-digit Aadhar
            case "PAN":
                return matchRegex(text, "\\b[A-Z]{5}\\d{4}[A-Z]\\b"); // PAN format
            case "DRIVING_LICENSE":
                return matchRegex(text, "\\b[A-Z]{2}[0-9]{13}\\b|\\b[A-Z]{2}-\\d{13}\\b|DL[-\\s:]?[A-Z0-9-]+");
            case "PASSPORT":
                return matchRegex(text, "\\b[A-Z][0-9]{7}\\b"); // 1 letter + 7 digits
            case "RATION_CARD":
                return matchRegex(text, "\\b[0-9]{9,12}\\b"); // Usually 9–12 digits
            default:
                return null;
        }
    }

    private String matchRegex(String text, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);
        if (matcher.find()) {
            return matcher.group().trim();
        }
        return null;
    }

    
    /**
     * Extracts name fields from text
     */
    private void extractNames(String text, IdDocumentContent.Builder contentBuilder) {
        // Pattern to match name fields in English and Hindi
        Pattern namePattern = Pattern.compile("(?i)(?:name|नाम)\\s*:?\\s*([A-Za-z\\s]+)", Pattern.MULTILINE);
        Matcher matcher = namePattern.matcher(text);
        
        if (matcher.find()) {
            String fullName = matcher.group(1).trim().replaceAll("\\s+", " ");
            String[] nameParts = fullName.split("\\s+");
            
            if (nameParts.length >= 1) {
                contentBuilder.firstName(nameParts[0]);
            }
            if (nameParts.length >= 2) {
                contentBuilder.lastName(nameParts[nameParts.length - 1]);
            }
            if (nameParts.length >= 3) {
                StringBuilder middleName = new StringBuilder();
                for (int i = 1; i < nameParts.length - 1; i++) {
                    middleName.append(nameParts[i]).append(" ");
                }
                contentBuilder.middleName(middleName.toString().trim());
            }
        }
    }
    
    /**
     * Extracts gender information
     */
    private void extractGender(String text, IdDocumentContent.Builder contentBuilder) {
        Pattern genderPattern = Pattern.compile("(?i)(?:gender|sex|लिंग)\\s*:?\\s*(male|female|m|f|पुरुष|महिला)", Pattern.MULTILINE);
        Matcher matcher = genderPattern.matcher(text);
        
        if (matcher.find()) {
            String genderValue = matcher.group(1).trim().toLowerCase();
            contentBuilder.gender(normalizeGender(genderValue));
        }
    }
    
    /**
     * Extracts date fields (DOB, issue date, expiry date)
     */
    private void extractDates(String text, IdDocumentContent.Builder contentBuilder, String idType) {
        // Various date patterns
        Pattern datePattern = Pattern.compile("\\b(\\d{1,2})[/-](\\d{1,2})[/-](\\d{4})\\b");
        Matcher matcher = datePattern.matcher(text);
        
        List<String> foundDates = new ArrayList<>();
        while (matcher.find()) {
            String date = String.format("%02d/%02d/%s", 
                    Integer.parseInt(matcher.group(1)), 
                    Integer.parseInt(matcher.group(2)), 
                    matcher.group(3));
            foundDates.add(date);
        }
        
        // Assign dates based on context
        if (!foundDates.isEmpty()) {
            contentBuilder.dateOfBirth(foundDates.get(0)); // First date usually DOB
            
            if (foundDates.size() > 1 && !idType.equals("AADHAR")) {
                contentBuilder.expiryDate(foundDates.get(foundDates.size() - 1)); // Last date usually expiry
            }
        }
    }
    
    /**
     * Extracts mobile number
     */
    private void extractMobileNumber(String text, IdDocumentContent.Builder contentBuilder) {
        // Indian mobile number pattern
        Pattern mobilePattern = Pattern.compile("\\b([6-9][0-9]{9})\\b");
        Matcher matcher = mobilePattern.matcher(text);
        
        if (matcher.find()) {
            contentBuilder.mobileNo(matcher.group(1));
        }
    }
    
    /**
     * Sets issuing authority based on document type
     */
    private void extractIssuingAuthority(String text, IdDocumentContent.Builder contentBuilder, String idType) {
        switch (idType.toUpperCase()) {
            case "AADHAR":
                contentBuilder.issuedBy("Unique Identification Authority of India (UIDAI)");
                break;
            case "PAN":
                contentBuilder.issuedBy("Income Tax Department, Government of India");
                break;
            case "DRIVING_LICENSE":
                contentBuilder.issuedBy("Regional Transport Office");
                break;
            case "PASSPORT":
                contentBuilder.issuedBy("Government of India");
                break;
            default:
                contentBuilder.issuedBy("Unknown Authority");
                break;
        }
    }
    
    /**
     * Extracts address details
     */
    private AddressDetails extractAddressDetails(String text) {
        // This would implement address extraction logic
        // For now, return basic structure
        return AddressDetails.builder()
                .country("India") // Default for Indian documents
                .build();
    }
    
    /**
     * Extracts additional details specific to document type
     */
    private void extractAdditionalDetailsByType(String text, List<AdditionalDetail> additionalDetails, String idType) {
        // Add document-specific additional details
        additionalDetails.add(AdditionalDetail.builder()
                .info("DOCUMENT_TYPE")
                .value(idType)
                .confidence(0.9)
                .build());
        
        additionalDetails.add(AdditionalDetail.builder()
                .info("TEXT_LENGTH")
                .value(String.valueOf(text.length()))
                .confidence(1.0)
                .build());
    }
    
    /**
     * Helper methods
     */
    private String normalizeGender(String genderValue) {
        if (genderValue.equals("m") || genderValue.equals("male") || genderValue.equals("पुरुष")) {
            return "Male";
        } else if (genderValue.equals("f") || genderValue.equals("female") || genderValue.equals("महिला")) {
            return "Female";
        }
        return genderValue.substring(0, 1).toUpperCase() + genderValue.substring(1);
    }
    
    private String determineFileType(String fileName) {
        if (fileName == null) return "unknown";
        
        String extension = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        switch (extension) {
            case "pdf": return "application/pdf";
            case "jpg":
            case "jpeg": return "image/jpeg";
            case "png": return "image/png";
            case "tiff": return "image/tiff";
            case "bmp": return "image/bmp";
            default: return "application/octet-stream";
        }
    }
    
    private IdDocumentExtractionResult createErrorResult(String extractionId, String fileName, String errorMessage) {
        return IdDocumentExtractionResult.builder()
                .id(extractionId)
                .fileName(fileName)
                .fileType("error")
                .idType(IdType.OTHER.getValue())
                .success(false)
                .errorMessage(errorMessage)
                .content(IdDocumentContent.builder()
                        .additionalDetails(Arrays.asList(
                                AdditionalDetail.builder()
                                        .info("ERROR")
                                        .value(errorMessage)
                                        .confidence(1.0)
                                        .build()
                        		 ))
                        .build())
                .build();
    }
}