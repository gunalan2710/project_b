package ai.simplfin.doczbot.services.masking2;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import ai.simplfin.doczbot.dto.AadhaarLocationDto;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EnhancedAadhaarMaskingServicetwo {
	
	private static final Logger log = LoggerFactory.getLogger(EnhancedAadhaarMaskingServicetwo.class);

    public enum MaskingStyle {
        SOLID_X,           // Simple X with background fill (RECOMMENDED)
        BLUR,              // Gaussian blur
        SMART_BACKGROUND,  // Color-matched background with X
        BLACK_BARS,        // Black rectangles (classic redaction)
        WHITE_FILL         // Simple white fill with X
    }

    /**
     * Main masking method - masks all detected Aadhaar locations
     */
    public BufferedImage maskAadhaarNumbers(BufferedImage image, 
                                           List<AadhaarLocationDto> locations,
                                           MaskingStyle style) {
        if (locations == null || locations.isEmpty()) {
            log.warn("No Aadhaar locations to mask");
            return image;
        }

        log.info("Starting masking with style: {} for {} location(s)", style, locations.size());
        
        // Create a copy to avoid modifying original
        BufferedImage result = deepCopy(image);
        Graphics2D g2d = result.createGraphics();
        
        // Enable high-quality rendering
        setupHighQualityRendering(g2d);
        
        int maskedCount = 0;
        for (AadhaarLocationDto location : locations) {
            Rectangle rect = new Rectangle(
                location.getX(), 
                location.getY(), 
                location.getWidth(), 
                location.getHeight()
            );
            
            // Expand rectangle slightly to ensure all digits are covered
            rect = expandRectangle(rect, 3, image.getWidth(), image.getHeight());
            
            log.info("Masking Aadhaar #{}: {} at ({}, {})", 
                    ++maskedCount, location.getUid(), rect.x, rect.y);
            
            switch (style) {
                case SOLID_X:
                    maskWithSolidX(g2d, rect, image);
                    break;
                case BLUR:
                    result = applyBlurToRegion(result, rect);
                    g2d = result.createGraphics();
                    setupHighQualityRendering(g2d);
                    break;
                case SMART_BACKGROUND:
                    maskWithSmartBackground(g2d, rect, image);
                    break;
                case BLACK_BARS:
                    maskWithBlackBars(g2d, rect);
                    break;
                case WHITE_FILL:
                    maskWithWhiteFill(g2d, rect);
                    break;
            }
        }
        
        g2d.dispose();
        log.info("Masking completed successfully for {} locations", maskedCount);
        return result;
    }

    /**
     * SOLID_X: Simple X with semi-transparent background (works on any background)
     */
    private void maskWithSolidX(Graphics2D g2d, Rectangle rect, BufferedImage original) {
        // Fill with semi-transparent white
        g2d.setColor(new Color(255, 255, 255, 230));
        g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        
        // Draw X with dark gray color
        g2d.setColor(new Color(80, 80, 80));
        g2d.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        int padding = 3;
        g2d.drawLine(rect.x + padding, rect.y + padding, 
                     rect.x + rect.width - padding, rect.y + rect.height - padding);
        g2d.drawLine(rect.x + rect.width - padding, rect.y + padding, 
                     rect.x + padding, rect.y + rect.height - padding);
        
        log.debug("Applied SOLID_X masking at ({}, {})", rect.x, rect.y);
    }

    /**
     * SMART_BACKGROUND: Samples background color and uses it for masking
     */
    private void maskWithSmartBackground(Graphics2D g2d, Rectangle rect, BufferedImage original) {
        // Sample background color from surrounding area
        Color bgColor = sampleBackgroundColor(original, rect);
        log.debug("Sampled background color: RGB({}, {}, {})", 
                 bgColor.getRed(), bgColor.getGreen(), bgColor.getBlue());
        
        // Fill with sampled background color
        g2d.setColor(bgColor);
        g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        
        // Draw X with darker shade of background
        Color xColor = bgColor.darker().darker();
        g2d.setColor(xColor);
        g2d.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        int padding = 2;
        g2d.drawLine(rect.x + padding, rect.y + padding, 
                     rect.x + rect.width - padding, rect.y + rect.height - padding);
        g2d.drawLine(rect.x + rect.width - padding, rect.y + padding, 
                     rect.x + padding, rect.y + rect.height - padding);
        
        log.debug("Applied SMART_BACKGROUND masking at ({}, {})", rect.x, rect.y);
    }

    /**
     * BLUR: Apply Gaussian blur to the region
     */
    private BufferedImage applyBlurToRegion(BufferedImage image, Rectangle rect) {
        try {
            // Ensure rectangle is within image bounds
            rect = constrainRectangle(rect, image.getWidth(), image.getHeight());
            
            if (rect.width <= 0 || rect.height <= 0) {
                log.warn("Invalid rectangle dimensions for blur: {}x{}", rect.width, rect.height);
                return image;
            }
            
            // Extract the region
            BufferedImage subImage = image.getSubimage(rect.x, rect.y, rect.width, rect.height);
            
            // Apply Gaussian blur
            float[] matrix = {
                1f/16f, 2f/16f, 1f/16f,
                2f/16f, 4f/16f, 2f/16f,
                1f/16f, 2f/16f, 1f/16f
            };
            
            ConvolveOp blur = new ConvolveOp(
                new Kernel(3, 3, matrix), 
                ConvolveOp.EDGE_NO_OP, 
                null
            );
            
            BufferedImage blurred = blur.filter(subImage, null);
            
            // Draw blurred region back
            Graphics2D g = image.createGraphics();
            setupHighQualityRendering(g);
            g.drawImage(blurred, rect.x, rect.y, null);
            g.dispose();
            
            log.debug("Applied BLUR masking at ({}, {})", rect.x, rect.y);
            return image;
            
        } catch (Exception e) {
            log.error("Error applying blur: {}", e.getMessage());
            return image;
        }
    }

    /**
     * BLACK_BARS: Classic redaction style
     */
    private void maskWithBlackBars(Graphics2D g2d, Rectangle rect) {
        g2d.setColor(Color.BLACK);
        g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        log.debug("Applied BLACK_BARS masking at ({}, {})", rect.x, rect.y);
    }

    /**
     * WHITE_FILL: Simple white fill with X
     */
    private void maskWithWhiteFill(Graphics2D g2d, Rectangle rect) {
        // Fill with white
        g2d.setColor(Color.WHITE);
        g2d.fillRect(rect.x, rect.y, rect.width, rect.height);
        
        // Draw X
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(2.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        int padding = 2;
        g2d.drawLine(rect.x + padding, rect.y + padding, 
                     rect.x + rect.width - padding, rect.y + rect.height - padding);
        g2d.drawLine(rect.x + rect.width - padding, rect.y + padding, 
                     rect.x + padding, rect.y + rect.height - padding);
        
        log.debug("Applied WHITE_FILL masking at ({}, {})", rect.x, rect.y);
    }

    /**
     * Sample background color from surrounding pixels
     */
    private Color sampleBackgroundColor(BufferedImage image, Rectangle rect) {
        int samples = 0;
        long r = 0, g = 0, b = 0;
        
        // Sample pixels from left and right edges
        for (int y = Math.max(0, rect.y); 
             y < Math.min(image.getHeight(), rect.y + rect.height); 
             y += 2) {
            
            // Left edge (5px to the left)
            int xLeft = Math.max(0, rect.x - 5);
            if (xLeft < image.getWidth()) {
                try {
                    int rgb = image.getRGB(xLeft, y);
                    r += (rgb >> 16) & 0xFF;
                    g += (rgb >> 8) & 0xFF;
                    b += rgb & 0xFF;
                    samples++;
                } catch (Exception e) {
                    // Skip invalid pixels
                }
            }
            
            // Right edge (5px to the right)
            int xRight = Math.min(image.getWidth() - 1, rect.x + rect.width + 5);
            if (xRight >= 0) {
                try {
                    int rgb = image.getRGB(xRight, y);
                    r += (rgb >> 16) & 0xFF;
                    g += (rgb >> 8) & 0xFF;
                    b += rgb & 0xFF;
                    samples++;
                } catch (Exception e) {
                    // Skip invalid pixels
                }
            }
        }
        
        // Sample pixels from top and bottom edges
        for (int x = Math.max(0, rect.x); 
             x < Math.min(image.getWidth(), rect.x + rect.width); 
             x += 2) {
            
            // Top edge (5px above)
            int yTop = Math.max(0, rect.y - 5);
            if (yTop < image.getHeight()) {
                try {
                    int rgb = image.getRGB(x, yTop);
                    r += (rgb >> 16) & 0xFF;
                    g += (rgb >> 8) & 0xFF;
                    b += rgb & 0xFF;
                    samples++;
                } catch (Exception e) {
                    // Skip invalid pixels
                }
            }
            
            // Bottom edge (5px below)
            int yBottom = Math.min(image.getHeight() - 1, rect.y + rect.height + 5);
            if (yBottom >= 0) {
                try {
                    int rgb = image.getRGB(x, yBottom);
                    r += (rgb >> 16) & 0xFF;
                    g += (rgb >> 8) & 0xFF;
                    b += rgb & 0xFF;
                    samples++;
                } catch (Exception e) {
                    // Skip invalid pixels
                }
            }
        }
        
        if (samples > 0) {
            return new Color((int)(r/samples), (int)(g/samples), (int)(b/samples));
        } else {
            log.warn("Could not sample background color, using white");
            return Color.WHITE;
        }
    }

    /**
     * Setup high-quality rendering hints
     */
    private void setupHighQualityRendering(Graphics2D g2d) {
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                            RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
                            RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION,
                            RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
    }

    /**
     * Expand rectangle by given pixels (ensures all digits are covered)
     */
    private Rectangle expandRectangle(Rectangle rect, int pixels, int maxWidth, int maxHeight) {
        return new Rectangle(
            Math.max(0, rect.x - pixels),
            Math.max(0, rect.y - pixels),
            Math.min(maxWidth - rect.x + pixels, rect.width + pixels * 2),
            Math.min(maxHeight - rect.y + pixels, rect.height + pixels * 2)
        );
    }

    /**
     * Constrain rectangle to image bounds
     */
    private Rectangle constrainRectangle(Rectangle rect, int maxWidth, int maxHeight) {
        int x = Math.max(0, Math.min(rect.x, maxWidth - 1));
        int y = Math.max(0, Math.min(rect.y, maxHeight - 1));
        int width = Math.min(rect.width, maxWidth - x);
        int height = Math.min(rect.height, maxHeight - y);
        return new Rectangle(x, y, width, height);
    }

    /**
     * Create a deep copy of BufferedImage
     */
    private BufferedImage deepCopy(BufferedImage source) {
        BufferedImage copy = new BufferedImage(
            source.getWidth(), 
            source.getHeight(), 
            source.getType()
        );
        Graphics2D g = copy.createGraphics();
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return copy;
    }
}