package ai.simplfin.doczbot;

import org.opencv.core.Core;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "ai.simplfin.doczbot")
public class DoczbottApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoczbottApplication.class, args);
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
	}

}
