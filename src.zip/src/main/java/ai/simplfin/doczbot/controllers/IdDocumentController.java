package ai.simplfin.doczbot.controllers;


import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import ai.simplfin.doczbot.dto.IdDocumentExtractionResult;
import ai.simplfin.doczbot.services.IdDocumentExtractionService;
import ai.simplfin.doczbot.services.masking.DocumentMaskingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * REST Controller for ID document text extraction
 * Supports multiple document types: Aadhar, PAN, Driving License, Passport
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/id-document")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class IdDocumentController {
	
	private static final Logger log = LoggerFactory.getLogger(IdDocumentController.class);

	@Autowired
    private IdDocumentExtractionService idDocumentExtractionService;
	@Autowired
	private DocumentMaskingService maskingService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Main endpoint for extracting text from ID documents
     * Supports PDF, image files with multiple extraction methods
     */
    @PostMapping(value = "/extract", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<IdDocumentExtractionResult> extractIdDocument(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "extractionMethod", required = false) String extractionMethod,
            @RequestParam(value = "idType", required = false) String idType) {
        
        log.info("Received ID document extraction request for file: {} with extraction method: {} and ID type: {}", 
                file.getOriginalFilename(), extractionMethod, idType);
        
        // Set default extraction method if not provided
        if (extractionMethod == null || extractionMethod.trim().isEmpty()) {
            extractionMethod = "DEFAULT_FALLBACK";
            log.info("No extraction method specified, using default fallback sequence");
        }
        
        // Validate input
        if (file.isEmpty()) {
            log.warn("Empty file received for ID document extraction");
            return ResponseEntity.badRequest().body(createErrorResult(
                    "Empty file provided", file.getOriginalFilename()));
        }
        
        // Validate extraction method
        if (!isValidExtractionMethod(extractionMethod)) {
            log.warn("Invalid extraction method provided: {}", extractionMethod);
            return ResponseEntity.badRequest().body(createErrorResult(
                    "Invalid extraction method: " + extractionMethod, file.getOriginalFilename()));
        }
        
        // Validate ID type if provided
        if (idType != null && !idType.trim().isEmpty() && !isValidIdType(idType)) {
            log.warn("Invalid ID type provided: {}", idType);
            return ResponseEntity.badRequest().body(createErrorResult(
                    "Invalid ID type: " + idType, file.getOriginalFilename()));
        }
        
        try {
            // Extract text from document
            IdDocumentExtractionResult result = idDocumentExtractionService.extractIdDocument(
                    file, extractionMethod, idType);
            
            // Log the JSON response for debugging
            try {
                String jsonResponse = objectMapper.writeValueAsString(result);
                log.info("Extraction result for file {}: {}", file.getOriginalFilename(), jsonResponse);
            } catch (Exception jsonException) {
                log.warn("Failed to serialize response to JSON for logging: {}", jsonException.getMessage());
            }
            
            if (result.getSuccess()) {
                log.info("ID document extraction completed successfully for file: {} using method: {}", 
                        file.getOriginalFilename(), result.getExtractionMethod());
                return ResponseEntity.ok(result);
            } else {
                log.warn("ID document extraction failed for file: {}, error: {}", 
                        file.getOriginalFilename(), result.getErrorMessage());
                return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(result);
            }
            
        } catch (Exception e) {
            log.error("Error processing ID document extraction for file: {}", file.getOriginalFilename(), e);
            return ResponseEntity.internalServerError().body(createErrorResult(
                    "Processing failed: " + e.getMessage(), file.getOriginalFilename()));
        }
    }
    
    /**
     * Test endpoint for specific extraction methods
     */
    @PostMapping(value = "/test/{method}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<IdDocumentExtractionResult> testExtractionMethod(
            @RequestParam("file") MultipartFile file,
            @PathVariable String method) {
        
        log.info("Testing {} extraction method with file: {}", method.toUpperCase(), file.getOriginalFilename());
        
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body(createErrorResult(
                    "Empty file provided", file.getOriginalFilename()));
        }
        
        if (!isValidExtractionMethod(method)) {
            return ResponseEntity.badRequest().body(createErrorResult(
                    "Invalid extraction method: " + method, file.getOriginalFilename()));
        }
        
        try {
            IdDocumentExtractionResult result = idDocumentExtractionService.extractIdDocument(
                    file, method.toUpperCase(), null);
            
            log.info("{} extraction test completed for file: {}", method.toUpperCase(), file.getOriginalFilename());
            return ResponseEntity.ok(result);
            
        } catch (Exception e) {
            log.error("Error testing {} extraction for file: {}", method, file.getOriginalFilename(), e);
            return ResponseEntity.internalServerError().body(createErrorResult(
                    method.toUpperCase() + " test failed: " + e.getMessage(), file.getOriginalFilename()));
        }
    }
    
    /**
     * Get supported extraction methods
     */
    @GetMapping("/methods")
    public ResponseEntity<Map<String, Object>> getSupportedMethods() {
        Map<String, Object> methods = new HashMap<>();
        
        Map<String, String> extractionMethods = new HashMap<>();
        extractionMethods.put("DEFAULT_FALLBACK", "Automatic method selection with fallback chain");
        extractionMethods.put("SPRING_AI_TIKA", "Spring AI with Apache Tika - Best for PDFs and documents");
        extractionMethods.put("TESSERACT_OCR", "Tesseract OCR - Best for image-based documents");
        extractionMethods.put("AI_EXTRACTION", "AI-powered extraction using Llama Vision (if enabled)");
        
        methods.put("extraction_methods", extractionMethods);
        
        Map<String, String> supportedIdTypes = new HashMap<>();
        supportedIdTypes.put("AUTO", "Auto-detect document type");
        supportedIdTypes.put("AADHAR", "Aadhar Card");
        supportedIdTypes.put("PAN", "PAN Card");
        supportedIdTypes.put("DRIVING_LICENSE", "Driving License");
        supportedIdTypes.put("PASSPORT", "Passport");
        supportedIdTypes.put("OTHER", "Other document types");
        
        methods.put("supported_id_types", supportedIdTypes);
        
        Map<String, String> supportedFormats = new HashMap<>();
        supportedFormats.put("PDF", "Portable Document Format");
        supportedFormats.put("JPEG/JPG", "JPEG Image Format");
        supportedFormats.put("PNG", "PNG Image Format");
        supportedFormats.put("TIFF", "TIFF Image Format");
        supportedFormats.put("BMP", "BMP Image Format");
        
        methods.put("supported_formats", supportedFormats);
        methods.put("max_file_size", "10MB");
        
        return ResponseEntity.ok(methods);
    }
    
    /**
     * Health check endpoint
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "ID Document Text Extraction Service");
        health.put("version", "1.0.0");
        health.put("timestamp", System.currentTimeMillis());
        
        return ResponseEntity.ok(health);
    }
    
    /**
     * API documentation endpoint
     */
    @GetMapping("/help")
    public ResponseEntity<Map<String, Object>> getApiHelp() {
        Map<String, Object> help = new HashMap<>();
        
        Map<String, String> endpoints = new HashMap<>();
        endpoints.put("POST /extract", "Extract text from ID documents");
        endpoints.put("POST /test/{method}", "Test specific extraction method");
        endpoints.put("GET /methods", "Get supported extraction methods and document types");
        endpoints.put("GET /health", "Service health check");
        endpoints.put("GET /help", "This help information");
        
        help.put("endpoints", endpoints);
        
        Map<String, String> parameters = new HashMap<>();
        parameters.put("file", "Document file to process (required)");
        parameters.put("extractionMethod", "Method to use (optional): DEFAULT_FALLBACK, SPRING_AI_TIKA, TESSERACT_OCR, AI_EXTRACTION");
        parameters.put("idType", "Type of ID document (optional): AUTO, AADHAR, PAN, DRIVING_LICENSE, PASSPORT, OTHER");
        
        help.put("parameters", parameters);
        
        Map<String, String> examples = new HashMap<>();
        examples.put("basic", "curl -X POST -F 'file=@aadhar.pdf' http://localhost:8080/api/v1/id-document/extract");
        examples.put("with_method", "curl -X POST -F 'file=@pan.jpg' -F 'extractionMethod=TESSERACT_OCR' -F 'idType=PAN' http://localhost:8080/api/v1/id-document/extract");
        examples.put("test_method", "curl -X POST -F 'file=@document.pdf' http://localhost:8080/api/v1/id-document/test/spring_ai_tika");
        
        help.put("examples", examples);
        
        return ResponseEntity.ok(help);
    }
    
    /**
     * Endpoint for extracting text from ID document images
     * Supports JPG, PNG, and other common image formats
     */
//    @PostMapping(value = "/upload/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
//    public ResponseEntity<IdDocumentExtractionResult> uploadDocumentImage(
//            @RequestParam("file") MultipartFile file,
//            @RequestParam(value = "extractionMethod", required = false) String extractionMethod,
//            @RequestParam(value = "masking", required = false) String masking,
//            @RequestParam(value = "idType", required = false) String idType,
//            @RequestParam(value = "maskingType", required = true) String maskingType) {
//    	try {
//    		log.info("Received image extraction request for file: {} with extraction method: {} and ID type: {}",
//                    file.getOriginalFilename(), extractionMethod, idType);
//    		IdDocumentExtractionResult result = maskingService.uploadDocumentImage(
//                    file, extractionMethod, idType, masking, maskingType);
//    		return ResponseEntity.ok(result);
//		} catch (Exception e) {
//			log.error("Error processing image file: {}", file.getOriginalFilename(), e);
//	        return ResponseEntity.internalServerError().body(createErrorResult(
//	                "Image processing failed: " + e.getMessage(), file.getOriginalFilename()));
//		}
//    }
    
    @GetMapping("/ping")
    public ResponseEntity<Map<String, String>> ping() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "ok");
        response.put("message", "ID Document service is reachable");
        return ResponseEntity.ok(response);
    }

    
    // Helper methods
    
    /**
     * Validates extraction method parameter
     */
    private boolean isValidExtractionMethod(String extractionMethod) {
        if (extractionMethod == null) return true;
        
        String method = extractionMethod.toUpperCase();
        return method.equals("DEFAULT_FALLBACK") ||
               method.equals("SPRING_AI_TIKA") || 
               method.equals("TESSERACT_OCR") ||
               method.equals("AI_EXTRACTION") ||
               // Support from your original code
               method.equals("PDF_READER") ||
               method.equals("GOOGLE_VISION_OCR");
    }
    
    /**
     * Validates ID type parameter
     */
    private boolean isValidIdType(String idType) {
        if (idType == null) return true;
        
        String type = idType.toUpperCase();
        return type.equals("AUTO") ||
               type.equals("AADHAR") || 
               type.equals("PAN") || 
               type.equals("DRIVING_LICENSE") ||
               type.equals("PASSPORT") ||
               type.equals("OTHER");
    }
    
    /**
     * Creates error result for API responses
     */
    private IdDocumentExtractionResult createErrorResult(String errorMessage, String fileName) {
        return IdDocumentExtractionResult.builder()
                .id(java.util.UUID.randomUUID().toString())
                .fileName(fileName != null ? fileName : "unknown")
                .fileType("error")
                .idType("OTHER")
                .success(false)
                .errorMessage(errorMessage)
                .extractionTime(java.time.LocalDateTime.now())
                .content(IdDocumentExtractionResult.IdDocumentContent.builder()
                        .additionalDetails(java.util.Arrays.asList(
                                IdDocumentExtractionResult.AdditionalDetail.builder()
                                        .info("ERROR")
                                        .value(errorMessage)
                                        .confidence(1.0)
                                        .build()
                        ))
                        .build())
                .build();
    }
}