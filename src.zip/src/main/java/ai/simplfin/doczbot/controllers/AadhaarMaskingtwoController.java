package ai.simplfin.doczbot.controllers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import ai.simplfin.doczbot.dto.AadhaarLocationDto;
import ai.simplfin.doczbot.services.masking.AadhaarDetectionService;
import ai.simplfin.doczbot.services.masking2.AadhaarMaskingServicetwo;
import ai.simplfin.doczbot.services.masking2.EnhancedAadhaarMaskingServicetwo.MaskingStyle;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/aadhaar")
@Slf4j
public class AadhaarMaskingtwoController {

	private static final Logger log = LoggerFactory.getLogger(AadhaarMaskingtwoController.class);
	
    @Autowired
    private AadhaarDetectionService detectionService;

    @Autowired
    private AadhaarMaskingServicetwo maskingService;

    /**
     * Mask Aadhaar with default style (from config)
     */
    @PostMapping("/mask")
    public ResponseEntity<?> maskAadhaar(@RequestParam("file") MultipartFile file) {
        return maskAadhaarWithStyle(file, null);
    }

    /**
     * Mask Aadhaar with specific style
     * Styles: SOLID_X, BLUR, SMART_BACKGROUND, BLACK_BARS, WHITE_FILL
     */
    @PostMapping("/mask-with-style")
    public ResponseEntity<?> maskAadhaarWithStyle(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "style", required = false) String styleParam) {
        
        try {
            log.info("Processing file: {} with style: {}", 
                    file.getOriginalFilename(), 
                    styleParam != null ? styleParam : "DEFAULT");

            // Read image
            BufferedImage image = ImageIO.read(file.getInputStream());
            if (image == null) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid image file"));
            }

            // Detect Aadhaar numbers
            List<AadhaarLocationDto> locations = detectionService.findAadhaarNumbers(image);
            
            if (locations.isEmpty()) {
                return ResponseEntity.ok()
                    .body(Map.of(
                        "message", "No Aadhaar numbers detected",
                        "count", 0
                    ));
            }

            // Mask with specified or default style
            BufferedImage maskedImage;
            if (styleParam != null && !styleParam.isEmpty()) {
                try {
                    MaskingStyle style = MaskingStyle.valueOf(styleParam.toUpperCase());
                    maskedImage = maskingService.maskWithStyle(image, locations, style);
                } catch (IllegalArgumentException e) {
                    return ResponseEntity.badRequest()
                        .body(Map.of("error", "Invalid masking style. Valid values: " +
                            "SOLID_X, BLUR, SMART_BACKGROUND, BLACK_BARS, WHITE_FILL"));
                }
            } else {
                maskedImage = maskingService.maskAadhaarInImage(image, locations);
            }

            // Convert to bytes
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(maskedImage, "JPEG", baos);
            byte[] imageBytes = baos.toByteArray();

            log.info("Successfully masked {} Aadhaar number(s) in file: {}", 
                    locations.size(), file.getOriginalFilename());

            // Return image with metadata in headers
            return ResponseEntity.ok()
                .contentType(MediaType.IMAGE_JPEG)
                .header("X-Aadhaar-Count", String.valueOf(locations.size()))
                .header("X-Masking-Style", styleParam != null ? styleParam : "DEFAULT")
                .body(imageBytes);

        } catch (Exception e) {
            log.error("Error processing file: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to process image: " + e.getMessage()));
        }
    }

    /**
     * Get masking metadata (count and locations) without actually masking
     */
    @PostMapping("/detect")
    public ResponseEntity<?> detectAadhaar(@RequestParam("file") MultipartFile file) {
        try {
            BufferedImage image = ImageIO.read(file.getInputStream());
            if (image == null) {
                return ResponseEntity.badRequest()
                    .body(Map.of("error", "Invalid image file"));
            }

            List<AadhaarLocationDto> locations = detectionService.findAadhaarNumbers(image);
            
            Map<String, Object> response = new HashMap<>();
            response.put("count", locations.size());
            response.put("locations", locations);
            response.put("filename", file.getOriginalFilename());

            return ResponseEntity.ok(response);

        } catch (Exception e) {
            log.error("Error detecting Aadhaar: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("error", "Failed to detect Aadhaar: " + e.getMessage()));
        }
    }

    /**
     * Get available masking styles
     */
    @GetMapping("/styles")
    public ResponseEntity<?> getAvailableStyles() {
        Map<String, String> styles = new HashMap<>();
        styles.put("SOLID_X", "Simple X with semi-transparent background (Recommended)");
        styles.put("SMART_BACKGROUND", "Intelligent color-matched background with X");
        styles.put("BLUR", "Gaussian blur effect");
        styles.put("BLACK_BARS", "Classic black redaction bars");
        styles.put("WHITE_FILL", "White fill with X marks");
        
        return ResponseEntity.ok(styles);
    }
}