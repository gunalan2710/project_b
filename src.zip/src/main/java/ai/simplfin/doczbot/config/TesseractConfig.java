package ai.simplfin.doczbot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import net.sourceforge.tess4j.Tesseract;

@Configuration
public class TesseractConfig {

    @Bean
    public Tesseract tesseract() {
        Tesseract tess = new Tesseract();
        tess.setDatapath("C:\\Program Files\\Tesseract-OCR\\tessdata"); // your tessdata path
        tess.setLanguage("eng");
        tess.setPageSegMode(11);
        tess.setOcrEngineMode(3);
        return tess;
    }
}
